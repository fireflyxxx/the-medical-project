module.exports=[45297,(a,b,c)=>{}];

//# sourceMappingURL=e67af_frontend-node__next-internal_server_app__not-found_page_actions_0901fa00.js.map