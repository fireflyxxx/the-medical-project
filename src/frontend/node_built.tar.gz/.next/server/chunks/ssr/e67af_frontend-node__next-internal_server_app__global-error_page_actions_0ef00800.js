module.exports=[42301,(a,b,c)=>{}];

//# sourceMappingURL=e67af_frontend-node__next-internal_server_app__global-error_page_actions_0ef00800.js.map