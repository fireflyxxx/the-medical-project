module.exports=[67547,(a,b,c)=>{"use strict";b.exports=a.r(82907).vendored["react-ssr"].ReactJsxRuntime},50273,(a,b,c)=>{"use strict";b.exports=a.r(82907).vendored["react-ssr"].ReactDOM}];

//# sourceMappingURL=28e52_next_dist_server_route-modules_app-page_vendored_ssr_9f88fc0e._.js.map