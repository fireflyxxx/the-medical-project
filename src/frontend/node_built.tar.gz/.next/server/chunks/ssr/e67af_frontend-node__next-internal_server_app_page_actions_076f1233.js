module.exports=[4373,(a,b,c)=>{}];

//# sourceMappingURL=e67af_frontend-node__next-internal_server_app_page_actions_076f1233.js.map