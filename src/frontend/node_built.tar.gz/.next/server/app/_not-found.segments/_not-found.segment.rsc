1:"$Sreact.fragment"
2:I[68468,["/doctor/_next/static/chunks/fc447c466c8de3ee.js","/doctor/_next/static/chunks/7e45d1616751225e.js"],"default"]
3:I[11946,["/doctor/_next/static/chunks/fc447c466c8de3ee.js","/doctor/_next/static/chunks/7e45d1616751225e.js"],"default"]
0:{"buildId":"9aw-okN1lhlm2WEENfkhf","rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"loading":null,"isPartial":false}
