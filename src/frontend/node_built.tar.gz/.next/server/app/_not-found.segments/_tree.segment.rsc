:HL["/doctor/_next/static/chunks/05ff46f6bd6f1c1b.css","style"]
:HL["/doctor/_next/static/chunks/a515b2c937a92266.css","style"]
0:{"buildId":"9aw-okN1lhlm2WEENfkhf","tree":{"name":"","paramType":null,"paramKey":"","hasRuntimePrefetch":false,"slots":{"children":{"name":"/_not-found","paramType":null,"paramKey":"/_not-found","hasRuntimePrefetch":false,"slots":{"children":{"name":"__PAGE__","paramType":null,"paramKey":"__PAGE__","hasRuntimePrefetch":false,"slots":null,"isRootLayout":false}},"isRootLayout":false}},"isRootLayout":true},"staleTime":300}
