1:"$Sreact.fragment"
2:I[8557,["/doctor/_next/static/chunks/7e45d1616751225e.js"],"ViewportBoundary"]
3:I[8557,["/doctor/_next/static/chunks/7e45d1616751225e.js"],"MetadataBoundary"]
4:"$Sreact.suspense"
0:{"buildId":"qXn8fNUqy_jiurGIKD7Cd","rsc":["$","$1","h",{"children":[null,["$","$L2",null,{"children":[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]}],["$","div",null,{"hidden":true,"children":["$","$L3",null,{"children":["$","$4",null,{"name":"Next.Metadata","children":[["$","title","0",{"children":"医疗影像AI分析平台 - 医生端"}],["$","meta","1",{"name":"description","content":"MediVision AI - 智能医疗影像分析系统"}]]}]}]}],["$","meta",null,{"name":"next-size-adjust","content":""}]]}],"loading":null,"isPartial":false}
